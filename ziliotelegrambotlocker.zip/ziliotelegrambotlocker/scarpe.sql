-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Dic 11, 2023 alle 17:54
-- Versione del server: 10.4.28-MariaDB
-- Versione PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scarpe`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `scarpe`
--

CREATE TABLE `scarpe` (
  `modello` varchar(255) NOT NULL,
  `produttore` varchar(255) NOT NULL,
  `linkalprodotto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `scarpe`
--

INSERT INTO `scarpe` (`modello`, `produttore`, `linkalprodotto`) VALUES
('Black Vulcanized Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/black-vulcanized-sneakers/13946201'),
('White Vulcanized Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-vulcanized-sneakers/13946221'),
('White Vulcanized Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-vulcanized-sneakers/13946241'),
('Yellow Replica Sneakers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/yellow-replica-sneakers/13493431'),
('Black Mid-Top Vulcanized Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/black-mid-top-vulcanized-sneakers/13946111'),
('White Odsy 1000 Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-odsy-1000-sneakers/13945521'),
('Red & White Out Of Office Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/red-and-white-out-of-office-sneakers/12350891'),
('Black Peterson OG Sneakers', 'Miharayasuhiro', 'https://www.ssense.com/en-it/men/product/miharayasuhiro/black-peterson-og-sneakers/14440061'),
('White Vulcanized Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-vulcanized-sneakers/12350641'),
('Blue & Gray Odsy 1000 Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/blue-and-gray-odsy-1000-sneakers/13946081'),
('Black Hank OG Sole Canvas Sneakers', 'Miharayasuhiro', 'https://www.ssense.com/en-it/men/product/miharayasuhiro/black-hank-og-sole-canvas-sneakers/14440051'),
('Green Tabi Boots', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/green-tabi-boots/13493671'),
('White & Blue Out Of Office Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-and-blue-out-of-office-sneakers/13521251'),
('Black Odsy 2000 Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/black-odsy-2000-sneakers/13946051'),
('Black Chain Loafers', 'JW Anderson', 'https://www.ssense.com/en-it/men/product/jw-anderson/black-chain-loafers/13883451'),
('Black & White SK8 STA #3 M1 Sneakers', 'BAPE', 'https://www.ssense.com/en-it/men/product/bape/black-and-white-sk8-sta-3-m1-sneakers/14287441'),
('Green High Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/green-high-sneakers/13443611'),
('White & Beige Vulcanized Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-and-beige-vulcanized-sneakers/12350681'),
('Black Vulcanized Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/black-vulcanized-sneakers/13946141'),
('Black Odsy 1000 Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/black-odsy-1000-sneakers/13945511'),
('Black Mega Bumper Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-mega-bumper-sneakers/13781231'),
('Off-White & Black Flesh Sneakers', 'Oakley Factory Team', 'https://www.ssense.com/en-it/men/product/oakley-factory-team/off-white-and-black-flesh-sneakers/14166171'),
('Green Tabi Loafers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/green-tabi-loafers/13493401'),
('Black Mega Bumper Geobasket Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-mega-bumper-geobasket-sneakers/13781211'),
('Black Fur Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-fur-sneakers/13443741'),
('Black Padlock Loafers', 'JW Anderson', 'https://www.ssense.com/en-it/men/product/jw-anderson/black-padlock-loafers/13883621'),
('Black Icon Low Boots', 'Moon Boot', 'https://www.ssense.com/en-it/men/product/moon-boot/black-icon-low-boots/15684741'),
('Black Cushioned Platform Slides', 'Y-3', 'https://www.ssense.com/en-it/men/product/y-3/black-cushioned-platform-slides/12616741'),
('Green Tabi Derbys', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/green-tabi-derbys/13493791'),
('Black Rubber Boots', 'AMBUSH', 'https://www.ssense.com/en-it/men/product/ambush/black-rubber-boots/13931201'),
('SSENSE Exclusive Black Roccia Vet Boots', 'Diemme', 'https://www.ssense.com/en-it/men/product/diemme/ssense-exclusive-black-roccia-vet-boots/14172111'),
('Green Tabi Babouches Loafers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/green-tabi-babouches-loafers/13493331'),
('Green Tabi Loafers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/green-tabi-loafers/13493361'),
('Brown Malibu Boots', 'AMIRI', 'https://www.ssense.com/en-it/men/product/amiri/brown-malibu-boots/13913321'),
('Brown Everest Boots', 'Diemme', 'https://www.ssense.com/en-it/men/product/diemme/brown-everest-boots/14172841'),
('Black Beatle Bozo Tractor Boots', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-beatle-bozo-tractor-boots/13444041'),
('Black Biker Ankle Boots', 'MM6 Maison Margiela', 'https://www.ssense.com/en-it/men/product/mm6-maison-margiela/black-biker-ankle-boots/14230251'),
('Black Driver Loafers', 'Ferragamo', 'https://www.ssense.com/en-it/men/product/salvatore-ferragamo/black-driver-loafers/13594811'),
('Green Wellipets Edition Frog Loafers', 'JW Anderson', 'https://www.ssense.com/en-it/men/product/jw-anderson/green-wellipets-edition-frog-loafers/15462111'),
('White & Black Kick Off Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-and-black-kick-off-sneakers/13945631'),
('Green & White Out Of Office Vintage Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/green-and-white-out-of-office-vintage-sneakers/12350941'),
('Black Blyde Chelsea Boots', 'Axel Arigato', 'https://www.ssense.com/en-it/men/product/axel-arigato/black-blyde-chelsea-boots/13977491'),
('Black Replica Sneakers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/black-replica-sneakers/13493421'),
('Black Polished Loafers', 'Toga Virilis', 'https://www.ssense.com/en-it/men/product/toga-virilis/black-polished-loafers/14228121'),
('White & Black Sponge Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-and-black-sponge-sneakers/13946011'),
('Black Icon Low Boots', 'Moon Boot', 'https://www.ssense.com/en-it/men/product/moon-boot/black-icon-low-boots/15684671'),
('Black Mono Slip-On Sneakers', '1017 ALYX 9SM', 'https://www.ssense.com/en-it/men/product/alyx/black-mono-slip-on-sneakers/13851101'),
('Black STA #3 M1 Sneakers', 'BAPE', 'https://www.ssense.com/en-it/men/product/bape/black-sta-3-m1-sneakers/14287561'),
('Black Flat Piped Slippers', 'LEMAIRE', 'https://www.ssense.com/en-it/men/product/lemaire/black-flat-piped-slippers/13794141'),
('Black Beatle Turbo Cyclops Boots', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-beatle-turbo-cyclops-boots/13444251'),
('Off-White & Black Dice Lo Sneakers', 'Axel Arigato', 'https://www.ssense.com/en-it/men/product/axel-arigato/off-white-and-black-dice-lo-sneakers/14017161'),
('Green Geobasket Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/green-geobasket-sneakers/13443461'),
('Black & White Skel Top Hi Sneakers', 'AMIRI', 'https://www.ssense.com/en-it/men/product/amiri/black-and-white-skel-top-hi-sneakers/13278841'),
('Black Work Chelsea Boots', '1017 ALYX 9SM', 'https://www.ssense.com/en-it/men/product/alyx/black-work-chelsea-boots/13798251'),
('Navy & White Out Of Office Vintage Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/navy-and-white-out-of-office-vintage-sneakers/12350921'),
('White & Navy Vulcanized Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-and-navy-vulcanized-sneakers/12350691'),
('Green Padlock Loafers', 'JW Anderson', 'https://www.ssense.com/en-it/men/product/jw-anderson/green-padlock-loafers/13883581'),
('Black Mega Bumper Geobasket Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-mega-bumper-geobasket-sneakers/13781181'),
('Black Roccia Vet Sport Boots', 'Diemme', 'https://www.ssense.com/en-it/men/product/diemme/black-roccia-vet-sport-boots/14172521'),
('Indigo SK8 STA Denim Sneakers', 'BAPE', 'https://www.ssense.com/en-it/men/product/bape/indigo-sk8-sta-denim-sneakers/12851381'),
('Off-White STA #1 Sneakers', 'BAPE', 'https://www.ssense.com/en-it/men/product/bape/off-white-sta-1-sneakers/14287581'),
('Black Pharaxus Sneakers', 'Raf Simons', 'https://www.ssense.com/en-it/men/product/raf-simons/black-pharaxus-sneakers/14449091'),
('Black & White Out Of Office Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/black-and-white-out-of-office-sneakers/13521281'),
('White Vulcanized Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-vulcanized-sneakers/13946121'),
('Green Sta #9 Sneakers', 'BAPE', 'https://www.ssense.com/en-it/men/product/bape/green-sta-9-sneakers/13343151'),
('White & Blue Out Of Office Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-and-blue-out-of-office-sneakers/12351041'),
('Brown & Burgundy Odsy 1000 Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/brown-and-burgundy-odsy-1000-sneakers/12350831'),
('Black Tabi Boots', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/black-tabi-boots/13493681'),
('White Yeezy Boost 350 V2 Sneakers', 'YEEZY', 'https://www.ssense.com/en-it/men/product/yeezy/white-yeezy-boost-350-v2-sneakers/15355611'),
('Off-White & Gray Odsy 2000 Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/off-white-and-gray-odsy-2000-sneakers/13946031'),
('SSENSE Exclusive Green & White Skell Top Low Sneakers', 'AMIRI', 'https://www.ssense.com/en-it/men/product/amiri/ssense-exclusive-green-and-white-skell-top-low-sneakers/14159391'),
('White Replica Espadrilles', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/white-replica-espadrilles/12990561'),
('Black Verona Chelsea Boots', 'Diemme', 'https://www.ssense.com/en-it/men/product/diemme/black-verona-chelsea-boots/14172441'),
('White Area Lo Sneakers', 'Axel Arigato', 'https://www.ssense.com/en-it/men/product/axel-arigato/white-area-lo-sneakers/13370241'),
('Brown Roccia Vet Boots', 'Diemme', 'https://www.ssense.com/en-it/men/product/diemme/brown-roccia-vet-boots/14172601'),
('Brown Alpago Boots', 'Diemme', 'https://www.ssense.com/en-it/men/product/diemme/brown-alpago-boots/14173071'),
('Black Everest Boots', 'Diemme', 'https://www.ssense.com/en-it/men/product/diemme/black-everest-boots/14172861'),
('Black Beatle Bozo Tractor Boots', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-beatle-bozo-tractor-boots/13444081'),
('Black Neal Sneakers', 'ROA', 'https://www.ssense.com/en-it/men/product/roa/black-neal-sneakers/14169001'),
('Red & White Stars Court Sneakers', 'AMIRI', 'https://www.ssense.com/en-it/men/product/amiri/red-and-white-stars-court-sneakers/13283861'),
('Off-White Geobasket Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/off-white-geobasket-sneakers/13443551'),
('Black Venga Boots', 'CAMPERLAB', 'https://www.ssense.com/en-it/men/product/camperlab/black-venga-boots/13841631'),
('Black Abstract Sneakers', 'Rick Owens DRKSHDW', 'https://www.ssense.com/en-it/men/product/rick-owens-drkshdw/black-abstract-sneakers/14010931'),
('SSENSE Exclusive Black & Navy Studded Loafers', 'Toga Virilis', 'https://www.ssense.com/en-it/men/product/toga-virilis/ssense-exclusive-black-and-navy-studded-loafers/14227931'),
('Black Tabi Boots', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/black-tabi-boots/13493751'),
('Green SK8 Sta #4 Sneakers', 'BAPE', 'https://www.ssense.com/en-it/men/product/bape/green-sk8-sta-4-sneakers/12851451'),
('Blue Tabi Denim Sneakers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/blue-tabi-denim-sneakers/12037181'),
('Blue Replica Sneakers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/blue-replica-sneakers/12037791'),
('Gray Runner Sneakers', 'Balenciaga', 'https://www.ssense.com/en-it/men/product/balenciaga/gray-runner-sneakers/14349161'),
('Black Boston Grip Clogs', 'Birkenstock', 'https://www.ssense.com/en-it/men/product/birkenstock/black-boston-grip-clogs/12996831'),
('Orange & White Out Of Office Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/orange-and-white-out-of-office-sneakers/14316241'),
('Orange Out Of Office Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/orange-out-of-office-sneakers/12350881'),
('Black Chuck 70 Sneakers', 'Converse', 'https://www.ssense.com/en-it/men/product/converse/black-chuck-70-sneakers/12842521'),
('White & Blue Out Of Office Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-and-blue-out-of-office-sneakers/12350861'),
('Blue Acs Pro Sneakers', 'Salomon', 'https://www.ssense.com/en-it/men/product/salomon/blue-acs-pro-sneakers/13597101'),
('Red & White Skel Top Low Sneakers', 'AMIRI', 'https://www.ssense.com/en-it/men/product/amiri/red-and-white-skel-top-low-sneakers/13283841'),
('Green Lace-Up Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/green-lace-up-sneakers/13781441'),
('Black Roccia Vet Boots', 'Diemme', 'https://www.ssense.com/en-it/men/product/diemme/black-roccia-vet-boots/14172581'),
('Black Double Bumper Sneakers', 'Rick Owens DRKSHDW', 'https://www.ssense.com/en-it/men/product/rick-owens-drkshdw/black-double-bumper-sneakers/14010961'),
('Gray & Blue Odsy 2000 Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/gray-and-blue-odsy-2000-sneakers/13946021'),
('Black Ami de Cœur Slides', 'AMI Paris', 'https://www.ssense.com/en-it/men/product/ami-alexandre-mattiussi/black-ami-de-coeur-slides/12169331'),
('Black Chuck 70 Low Sneakers', 'Converse', 'https://www.ssense.com/en-it/men/product/converse/black-chuck-70-low-sneakers/12842531'),
('SSENSE Exclusive Black & Yellow Oxfords', 'Stefan Cooke', 'https://www.ssense.com/en-it/men/product/stefan-cooke/ssense-exclusive-black-and-yellow-oxfords/14311311'),
('Black New Logo Slides', 'Palm Angels', 'https://www.ssense.com/en-it/men/product/palm-angels/black-new-logo-slides/13927611'),
('Black Lunar Tractor Boots', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-lunar-tractor-boots/13444151'),
('Black Tabi Babouches Loafers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/black-tabi-babouches-loafers/12037421'),
('Red & White Out Of Office Vintage Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/red-and-white-out-of-office-vintage-sneakers/12350911'),
('Purple Replica Sneakers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/purple-replica-sneakers/13493441'),
('Black Mono Boots', '1017 ALYX 9SM', 'https://www.ssense.com/en-it/men/product/alyx/black-mono-boots/13849131'),
('White & Beige Slim Out Of Office Sneakers', 'Off-White', 'https://www.ssense.com/en-it/men/product/off-white/white-and-beige-slim-out-of-office-sneakers/12351061'),
('Black Stars Court Slip-On Sneakers', 'AMIRI', 'https://www.ssense.com/en-it/men/product/amiri/black-stars-court-slip-on-sneakers/13283891'),
('Black Replica Sneakers', 'Maison Margiela', 'https://www.ssense.com/en-it/men/product/maison-margiela/black-replica-sneakers/14042951'),
('Black High Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-high-sneakers/13443661'),
('Black Fur Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-fur-sneakers/13443471'),
('Black Geobasket Sneakers', 'Rick Owens', 'https://www.ssense.com/en-it/men/product/rick-owens/black-geobasket-sneakers/13443531'),
('SSENSE Exclusive Brown Loafers', 'Toga Virilis', 'https://www.ssense.com/en-it/men/product/toga-virilis/ssense-exclusive-brown-loafers/14227881');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
